package ___3__������Shape;

public class Test {
	public static void main(String[] args) {
		new Circle(1, Math.PI).calArea();
		new Rectangle(2, 2).calArea();
		new Triangle(2, 2).calArea();
	}
} 