package ___6__����;

public class Tets_Person {
	public static void main(String[] args) {
		new Person("czs", 19).Diplay();
	}
}
